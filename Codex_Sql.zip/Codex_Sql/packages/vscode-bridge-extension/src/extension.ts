import * as http from "node:http";
import * as vscode from "vscode";

const CONFIG_SECTION = "vscodeBridgeMcp";
const DEFAULT_PORT = 32173;
const HOST = "127.0.0.1";

type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };

let activeBridge: BridgeServer | undefined;

export function activate(context: vscode.ExtensionContext): void {
  const output = vscode.window.createOutputChannel("VS Code Bridge MCP");
  const bridge = new BridgeServer(output);
  activeBridge = bridge;

  context.subscriptions.push(output);
  context.subscriptions.push(
    { dispose: () => void bridge.stop("Extension deactivated.") },
    vscode.commands.registerCommand("vscodeBridgeMcp.showStatus", async () => {
      const status = bridge.getStatus();
      const message = status.running
        ? `VS Code bridge is listening on ${status.baseUrl}`
        : "VS Code bridge is stopped.";
      await vscode.window.showInformationMessage(message);
    }),
    vscode.commands.registerCommand("vscodeBridgeMcp.startBridge", async () => {
      await bridge.start("Started from command palette.");
      await vscode.window.showInformationMessage(`VS Code bridge started at ${bridge.getStatus().baseUrl}`);
    }),
    vscode.commands.registerCommand("vscodeBridgeMcp.restartBridge", async () => {
      await bridge.restart("Restarted from command palette.");
      await vscode.window.showInformationMessage(`VS Code bridge restarted at ${bridge.getStatus().baseUrl}`);
    }),
    vscode.commands.registerCommand("vscodeBridgeMcp.stopBridge", async () => {
      await bridge.stop("Stopped from command palette.");
      await vscode.window.showInformationMessage("VS Code bridge stopped.");
    }),
    vscode.workspace.onDidChangeConfiguration(async (event) => {
      if (event.affectsConfiguration(CONFIG_SECTION)) {
        await bridge.restart("Configuration changed.");
      }
    })
  );

  void bridge.start("Extension activated.");
}

export async function deactivate(): Promise<void> {
  await activeBridge?.stop("Extension deactivated.");
}

class BridgeServer {
  private readonly output: vscode.OutputChannel;
  private server: http.Server | undefined;
  private port = DEFAULT_PORT;

  public constructor(output: vscode.OutputChannel) {
    this.output = output;
  }

  public getStatus(): { running: boolean; baseUrl: string } {
    return {
      running: this.server !== undefined,
      baseUrl: `http://${HOST}:${this.port}`
    };
  }

  public async start(reason: string): Promise<void> {
    if (this.server) {
      return;
    }

    this.port = getConfiguredPort();
    this.server = http.createServer((request, response) => {
      void this.handleRequest(request, response);
    });

    await new Promise<void>((resolve, reject) => {
      const server = this.server;
      if (!server) {
        reject(new Error("Bridge server was not created."));
        return;
      }

      const onError = (error: Error): void => reject(error);
      server.once("error", onError);
      server.listen(this.port, HOST, () => {
        server.off("error", onError);
        resolve();
      });
    });

    this.log(`${reason} Listening on http://${HOST}:${this.port}`);
  }

  public async stop(reason: string): Promise<void> {
    if (!this.server) {
      return;
    }

    const server = this.server;
    this.server = undefined;

    await new Promise<void>((resolve, reject) => {
      server.close((error) => {
        if (error) {
          reject(error);
          return;
        }

        resolve();
      });
    });

    this.log(`${reason} Bridge stopped.`);
  }

  public async restart(reason: string): Promise<void> {
    await this.stop(reason);
    await this.start(reason);
  }

  private async handleRequest(request: http.IncomingMessage, response: http.ServerResponse): Promise<void> {
    const url = new URL(request.url ?? "/", `http://${HOST}:${this.port}`);
    const method = request.method ?? "GET";

    if (getLogRequestsEnabled()) {
      this.log(`${method} ${url.pathname}`);
    }

    try {
      if (method === "GET" && url.pathname === "/health") {
        this.writeJson(response, 200, {
          ok: true,
          bridgeUrl: `http://${HOST}:${this.port}`,
          focused: vscode.window.state.focused
        });
        return;
      }

      if (method === "GET" && url.pathname === "/workspace-state") {
        this.writeJson(response, 200, getWorkspaceState());
        return;
      }

      if (method === "GET" && url.pathname === "/commands") {
        const filter = url.searchParams.get("filter") ?? "";
        const includeInternal = url.searchParams.get("includeInternal") === "true";
        const limit = parsePositiveInteger(url.searchParams.get("limit")) ?? 250;
        const commands = await vscode.commands.getCommands(includeInternal);
        const filtered = commands
          .filter((command) => filter.length === 0 || command.toLowerCase().includes(filter.toLowerCase()))
          .sort()
          .slice(0, limit);

        this.writeJson(response, 200, {
          count: filtered.length,
          commands: filtered
        });
        return;
      }

      if (method === "POST" && url.pathname === "/commands/execute") {
        const body = await readJsonBody(request);
        const command = asString(body.command, "command");
        const args = Array.isArray(body.args) ? body.args : [];
        const result = await vscode.commands.executeCommand(command, ...args);

        this.writeJson(response, 200, {
          ok: true,
          command,
          result: serializeForWire(result)
        });
        return;
      }

      if (method === "POST" && url.pathname === "/editor/active-document") {
        const body = await readJsonBody(request);
        this.writeJson(response, 200, getActiveDocument(body));
        return;
      }

      if (method === "POST" && url.pathname === "/workspace/read-document") {
        const body = await readJsonBody(request);
        const result = await readDocument(body);
        this.writeJson(response, 200, result);
        return;
      }

      if (method === "POST" && url.pathname === "/workspace/find-files") {
        const body = await readJsonBody(request);
        const pattern = asString(body.pattern, "pattern");
        const exclude = typeof body.exclude === "string" ? body.exclude : undefined;
        const maxResults = clamp(parseNumber(body.maxResults) ?? 100, 1, 500);
        const files = await vscode.workspace.findFiles(pattern, exclude, maxResults);

        this.writeJson(response, 200, {
          count: files.length,
          files: files.map((file) => uriToJson(file))
        });
        return;
      }

      if (method === "POST" && url.pathname === "/editor/open") {
        const body = await readJsonBody(request);
        const result = await openEditor(body);
        this.writeJson(response, 200, result);
        return;
      }

      if (method === "POST" && url.pathname === "/window/message") {
        const body = await readJsonBody(request);
        const message = asString(body.message, "message");
        const severity = typeof body.severity === "string" ? body.severity : "info";

        if (severity === "error") {
          await vscode.window.showErrorMessage(message);
        } else if (severity === "warning") {
          await vscode.window.showWarningMessage(message);
        } else {
          await vscode.window.showInformationMessage(message);
        }

        this.writeJson(response, 200, {
          ok: true,
          severity,
          message
        });
        return;
      }

      this.writeJson(response, 404, { error: `Unknown route: ${method} ${url.pathname}` });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.writeJson(response, 500, { error: message });
    }
  }

  private log(message: string): void {
    this.output.appendLine(`[${new Date().toISOString()}] ${message}`);
  }

  private writeJson(response: http.ServerResponse, statusCode: number, body: JsonValue | Record<string, unknown>): void {
    response.statusCode = statusCode;
    response.setHeader("content-type", "application/json; charset=utf-8");
    response.end(JSON.stringify(body));
  }
}

function getWorkspaceState(): JsonValue {
  return {
    folders: (vscode.workspace.workspaceFolders ?? []).map((folder) => ({
      name: folder.name,
      uri: uriToJson(folder.uri)
    })),
    activeEditor: vscode.window.activeTextEditor ? editorToJson(vscode.window.activeTextEditor) : null,
    visibleEditors: vscode.window.visibleTextEditors.map((editor) => editorToJson(editor)),
    focused: vscode.window.state.focused
  };
}

function getActiveDocument(input: Record<string, unknown>): JsonValue {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    return {
      active: false
    };
  }

  const includeText = Boolean(input.includeText);
  const selectionOnly = Boolean(input.selectionOnly);
  const maxChars = clamp(parseNumber(input.maxChars) ?? 20000, 1, 200000);
  const document = editor.document;
  const fullText = selectionOnly
    ? editor.selections.map((selection) => document.getText(selection)).join("\n\n")
    : document.getText();

  const result: Record<string, JsonValue> = {
    active: true,
    editor: editorToJson(editor)
  };

  if (includeText) {
    result.text = truncate(fullText, maxChars);
  }

  return result;
}

async function readDocument(input: Record<string, unknown>): Promise<JsonValue> {
  const uri = resolveUri(input);
  const document = await vscode.workspace.openTextDocument(uri);
  const maxChars = clamp(parseNumber(input.maxChars) ?? 40000, 1, 200000);

  let text: string;
  const startLine = parseNumber(input.startLine);
  const endLine = parseNumber(input.endLine);

  if (startLine === undefined && endLine === undefined) {
    text = document.getText();
  } else {
    const safeStart = clamp(startLine ?? 0, 0, Math.max(0, document.lineCount - 1));
    const safeEnd = clamp(endLine ?? safeStart, safeStart, Math.max(0, document.lineCount - 1));
    const lastLine = document.lineAt(safeEnd);
    const range = new vscode.Range(safeStart, 0, safeEnd, lastLine.range.end.character);
    text = document.getText(range);
  }

  return {
    document: documentToJson(document),
    text: truncate(text, maxChars)
  };
}

async function openEditor(input: Record<string, unknown>): Promise<JsonValue> {
  const uri = resolveUri(input);
  const document = await vscode.workspace.openTextDocument(uri);
  const editor = await vscode.window.showTextDocument(document, {
    preview: Boolean(input.preview),
    preserveFocus: Boolean(input.preserveFocus),
    viewColumn: parseViewColumn(input.viewColumn)
  });

  const startLine = parseNumber(input.startLine);
  const startCharacter = parseNumber(input.startCharacter) ?? 0;
  const endLine = parseNumber(input.endLine) ?? startLine;
  const endCharacter = parseNumber(input.endCharacter) ?? startCharacter;

  if (startLine !== undefined) {
    const safeStartLine = clamp(startLine, 0, Math.max(0, document.lineCount - 1));
    const safeEndLine = clamp(endLine ?? safeStartLine, safeStartLine, Math.max(0, document.lineCount - 1));
    const start = new vscode.Position(safeStartLine, Math.max(0, startCharacter));
    const end = new vscode.Position(safeEndLine, Math.max(0, endCharacter));
    const selection = new vscode.Selection(start, end);
    editor.selection = selection;
    editor.revealRange(selection, vscode.TextEditorRevealType.InCenter);
  }

  return {
    ok: true,
    editor: editorToJson(editor)
  };
}

async function readJsonBody(request: http.IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];

  for await (const chunk of request) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }

  if (chunks.length === 0) {
    return {};
  }

  const body = Buffer.concat(chunks).toString("utf8");
  const parsed = JSON.parse(body) as unknown;

  if (!isRecord(parsed)) {
    throw new Error("Expected a JSON object body.");
  }

  return parsed;
}

function editorToJson(editor: vscode.TextEditor): JsonValue {
  return {
    document: documentToJson(editor.document),
    selections: editor.selections.map((selection) => selectionToJson(selection)),
    viewColumn: editor.viewColumn ?? null
  };
}

function documentToJson(document: vscode.TextDocument): JsonValue {
  return {
    uri: uriToJson(document.uri),
    fileName: document.fileName,
    languageId: document.languageId,
    version: document.version,
    lineCount: document.lineCount,
    isDirty: document.isDirty,
    isUntitled: document.isUntitled
  };
}

function selectionToJson(selection: vscode.Selection): JsonValue {
  return {
    start: {
      line: selection.start.line,
      character: selection.start.character
    },
    end: {
      line: selection.end.line,
      character: selection.end.character
    },
    isEmpty: selection.isEmpty
  };
}

function uriToJson(uri: vscode.Uri): JsonValue {
  return {
    scheme: uri.scheme,
    fsPath: uri.fsPath,
    path: uri.path,
    uri: uri.toString()
  };
}

function serializeForWire(value: unknown, depth = 0, seen = new WeakSet<object>()): JsonValue {
  if (depth > 5) {
    return "[MaxDepth]";
  }

  if (value === null) {
    return null;
  }

  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return value;
  }

  if (typeof value === "bigint") {
    return value.toString();
  }

  if (typeof value === "undefined") {
    return null;
  }

  if (value instanceof vscode.Uri) {
    return uriToJson(value);
  }

  if (value instanceof Error) {
    return {
      name: value.name,
      message: value.message,
      stack: value.stack ?? ""
    };
  }

  if (Array.isArray(value)) {
    return value.slice(0, 100).map((entry) => serializeForWire(entry, depth + 1, seen));
  }

  if (typeof value === "object") {
    if (seen.has(value)) {
      return "[Circular]";
    }

    seen.add(value);
    const result: Record<string, JsonValue> = {};

    for (const [key, entry] of Object.entries(value).slice(0, 100)) {
      if (typeof entry === "function") {
        continue;
      }

      result[key] = serializeForWire(entry, depth + 1, seen);
    }

    return result;
  }

  return String(value);
}

function resolveUri(input: Record<string, unknown>): vscode.Uri {
  if (typeof input.uri === "string" && input.uri.length > 0) {
    return vscode.Uri.parse(input.uri);
  }

  if (typeof input.path === "string" && input.path.length > 0) {
    return vscode.Uri.file(input.path);
  }

  throw new Error("Either 'path' or 'uri' is required.");
}

function parseViewColumn(value: unknown): vscode.ViewColumn | undefined {
  const numeric = parseNumber(value);
  if (numeric === undefined) {
    return undefined;
  }

  if (numeric === 1) {
    return vscode.ViewColumn.One;
  }

  if (numeric === 2) {
    return vscode.ViewColumn.Two;
  }

  if (numeric === 3) {
    return vscode.ViewColumn.Three;
  }

  return undefined;
}

function asString(value: unknown, fieldName: string): string {
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(`Expected '${fieldName}' to be a non-empty string.`);
  }

  return value;
}

function parseNumber(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  return undefined;
}

function parsePositiveInteger(value: string | null): number | undefined {
  if (!value) {
    return undefined;
  }

  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function truncate(value: string, maxChars: number): string {
  if (value.length <= maxChars) {
    return value;
  }

  return `${value.slice(0, maxChars)}\n...[truncated]`;
}

function getConfiguredPort(): number {
  const configured = vscode.workspace.getConfiguration(CONFIG_SECTION).get<number>("port", DEFAULT_PORT);
  return clamp(configured, 1024, 65535);
}

function getLogRequestsEnabled(): boolean {
  return vscode.workspace.getConfiguration(CONFIG_SECTION).get<boolean>("logRequests", false);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
