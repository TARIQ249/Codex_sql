## VS Code Bridge MCP Companion

Local companion extension for the workspace `vscode-bridge` MCP server.

It starts an HTTP bridge inside VS Code so external MCP clients can access
selected VS Code APIs through the companion server.
