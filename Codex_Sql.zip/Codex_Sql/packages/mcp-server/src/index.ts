#!/usr/bin/env node

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { VsCodeBridgeClient } from "./vscodeBridgeClient.js";

const bridge = new VsCodeBridgeClient();
const server = new McpServer({
  name: "vscode-bridge",
  version: "0.1.0"
});

server.tool("vscode_bridge_health", {}, async () => formatResult(await bridge.health()));

server.tool("vscode_get_workspace_state", {}, async () => formatResult(await bridge.getWorkspaceState()));

server.tool(
  "vscode_get_active_document",
  {
    includeText: z.boolean().optional(),
    selectionOnly: z.boolean().optional(),
    maxChars: z.number().int().positive().max(200000).optional()
  },
  async (input) => formatResult(await bridge.getActiveDocument(input))
);

server.tool(
  "vscode_read_document",
  {
    path: z.string().optional(),
    uri: z.string().optional(),
    startLine: z.number().int().min(0).optional(),
    endLine: z.number().int().min(0).optional(),
    maxChars: z.number().int().positive().max(200000).optional()
  },
  async (input) => formatResult(await bridge.readDocument(input))
);

server.tool(
  "vscode_find_files",
  {
    pattern: z.string(),
    exclude: z.string().optional(),
    maxResults: z.number().int().positive().max(500).optional()
  },
  async (input) => formatResult(await bridge.findFiles(input))
);

server.tool(
  "vscode_open_file",
  {
    path: z.string().optional(),
    uri: z.string().optional(),
    preview: z.boolean().optional(),
    preserveFocus: z.boolean().optional(),
    viewColumn: z.number().int().min(1).max(3).optional(),
    startLine: z.number().int().min(0).optional(),
    startCharacter: z.number().int().min(0).optional(),
    endLine: z.number().int().min(0).optional(),
    endCharacter: z.number().int().min(0).optional()
  },
  async (input) => formatResult(await bridge.openFile(input))
);

server.tool(
  "vscode_list_commands",
  {
    filter: z.string().optional(),
    includeInternal: z.boolean().optional(),
    limit: z.number().int().positive().max(1000).optional()
  },
  async (input) => formatResult(await bridge.listCommands(input))
);

server.tool(
  "vscode_execute_command",
  {
    command: z.string(),
    args: z.array(z.any()).optional()
  },
  async (input) => formatResult(await bridge.executeCommand(input))
);

server.tool(
  "vscode_show_message",
  {
    message: z.string(),
    severity: z.enum(["info", "warning", "error"]).optional()
  },
  async (input) => formatResult(await bridge.showMessage(input))
);

async function main(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

function formatResult(value: unknown): { content: Array<{ type: "text"; text: string }> } {
  return {
    content: [
      {
        type: "text",
        text: JSON.stringify(value, null, 2)
      }
    ]
  };
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.stack ?? error.message : String(error);
  console.error(message);
  process.exit(1);
});
