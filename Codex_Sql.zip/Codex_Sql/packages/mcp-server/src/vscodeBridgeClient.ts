export interface BridgeClientOptions {
  baseUrl?: string;
  timeoutMs?: number;
}

export class VsCodeBridgeClient {
  private readonly baseUrl: string;
  private readonly timeoutMs: number;

  public constructor(options: BridgeClientOptions = {}) {
    this.baseUrl = (options.baseUrl ?? process.env.VSCODE_BRIDGE_URL ?? "http://127.0.0.1:32173").replace(/\/+$/, "");
    this.timeoutMs = options.timeoutMs ?? Number(process.env.VSCODE_BRIDGE_TIMEOUT_MS ?? "15000");
  }

  public health(): Promise<unknown> {
    return this.request("GET", "/health");
  }

  public getWorkspaceState(): Promise<unknown> {
    return this.request("GET", "/workspace-state");
  }

  public getActiveDocument(input: Record<string, unknown>): Promise<unknown> {
    return this.request("POST", "/editor/active-document", input);
  }

  public readDocument(input: Record<string, unknown>): Promise<unknown> {
    return this.request("POST", "/workspace/read-document", input);
  }

  public findFiles(input: Record<string, unknown>): Promise<unknown> {
    return this.request("POST", "/workspace/find-files", input);
  }

  public openFile(input: Record<string, unknown>): Promise<unknown> {
    return this.request("POST", "/editor/open", input);
  }

  public listCommands(input: Record<string, unknown>): Promise<unknown> {
    const search = new URLSearchParams();

    const filter = input.filter;
    const includeInternal = input.includeInternal;
    const limit = input.limit;

    if (typeof filter === "string" && filter.length > 0) {
      search.set("filter", filter);
    }

    if (typeof includeInternal === "boolean") {
      search.set("includeInternal", String(includeInternal));
    }

    if (typeof limit === "number" && Number.isFinite(limit)) {
      search.set("limit", String(limit));
    }

    const suffix = search.size > 0 ? `?${search.toString()}` : "";
    return this.request("GET", `/commands${suffix}`);
  }

  public executeCommand(input: Record<string, unknown>): Promise<unknown> {
    return this.request("POST", "/commands/execute", input);
  }

  public showMessage(input: Record<string, unknown>): Promise<unknown> {
    return this.request("POST", "/window/message", input);
  }

  private async request(method: string, path: string, body?: unknown): Promise<unknown> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        method,
        headers: body === undefined ? undefined : { "content-type": "application/json" },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal
      });

      const text = await response.text();
      const parsed = text.length > 0 ? safeParseJson(text) : null;

      if (!response.ok) {
        const message =
          isRecord(parsed) && typeof parsed.error === "string"
            ? parsed.error
            : `VS Code bridge request failed with status ${response.status}`;
        throw new Error(message);
      }

      return parsed;
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        throw new Error(`Timed out connecting to the VS Code bridge at ${this.baseUrl}`);
      }

      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }
}

function safeParseJson(value: string): unknown {
  try {
    return JSON.parse(value) as unknown;
  } catch {
    return { raw: value };
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
